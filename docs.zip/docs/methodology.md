# Detailed Methodology

## Scientific Background

The Pasteurellaceae family comprises a diverse group of Gram-negative bacteria that includes important pathogens affecting both humans and animals. Understanding the phylogenetic relationships, geographic distribution patterns, and host specificity of these organisms is crucial for epidemiological surveillance, public health preparedness, and understanding zoonotic transmission dynamics.

This analysis employs a comprehensive phylogenomic approach that integrates multiple data types and analytical methods to provide insights into the evolutionary history and epidemiological characteristics of Pasteurellaceae bacteria.

## Methodological Approach

### 1. Genome Annotation Strategy

**Rationale:** Accurate gene annotation is fundamental for downstream phylogenetic and pangenome analyses. Prokka was selected for its speed, accuracy, and standardized output format suitable for comparative genomics.

**Method:** All genome assemblies are annotated using Prokka v1.14.6+ with the following parameters:
- Kingdom: Bacteria
- Genus: Pasteurella (when applicable)
- Gram staining: Negative
- CPU cores: 12 (adjustable based on available resources)

**Quality Control:** Annotation completeness is assessed by examining the number of predicted genes, tRNAs, and rRNAs. Genomes with unusually low gene counts or missing essential genes are flagged for manual review.

### 2. Sequence Alignment Methodology

**Multiple Sequence Alignment:** MAFFT v7.490+ is used for all sequence alignments due to its accuracy and efficiency with large datasets.

**Parameters:**
- Algorithm: Auto-selection based on dataset size
- Direction adjustment: Enabled to handle sequences in different orientations
- Amino acid sequences: Protein-specific scoring matrices
- Nucleotide sequences: Standard DNA substitution models

**Alignment Quality Assessment:** Alignments are manually inspected for:
- Appropriate sequence length distribution
- Reasonable gap distribution
- Absence of obvious misalignments
- Conservation patterns consistent with expected phylogenetic signal

### 3. Phylogenetic Analysis Framework

#### 3.1 Maximum Likelihood Tree Construction

**Software:** IQ-TREE v2.1.0+ is employed for maximum likelihood phylogenetic inference due to its advanced model selection capabilities and statistical support measures.

**Model Selection:** The ModelFinder Plus (MFP) algorithm automatically selects the best-fitting substitution model based on:
- Akaike Information Criterion (AIC)
- Bayesian Information Criterion (BIC)
- Corrected AIC (AICc)

**Statistical Support:**
- Bootstrap support: 1000 replicates using the ultrafast bootstrap (UFBoot) method
- SH-aLRT support: 1000 replicates for additional branch support assessment

**Tree Rooting Strategy:** Both 16S rRNA and core genome trees are midpoint-rooted. This approach is justified by:
1. Absence of suitable outgroup taxa with sufficient phylogenetic distance
2. High genetic similarity among Pasteurellaceae members
3. Assumption of relatively constant evolutionary rates (molecular clock)

**Limitations of Midpoint Rooting:** While midpoint rooting assumes a molecular clock, this assumption may not hold perfectly across all lineages. However, given the constraints of working within a single bacterial family and the lack of appropriate outgroups, midpoint rooting provides a reasonable and consistent rooting strategy.

#### 3.2 Pangenome Analysis

**Software:** Roary v3.13.0+ is used for pangenome analysis due to its efficiency with large bacterial datasets and comprehensive output formats.

**Parameters:**
- Minimum percentage identity: 95% (BLASTp)
- Core gene threshold: 99% (genes present in ≥99% of isolates)
- Paralogs splitting: Enabled
- Core gene alignment: Generated using MAFFT

**Gene Classification:**
- **Core genes:** Present in ≥99% of isolates
- **Soft core genes:** Present in 95-99% of isolates  
- **Shell genes:** Present in 15-95% of isolates
- **Cloud genes:** Present in <15% of isolates

### 4. Geographic Analysis Methods

#### 4.1 Geocoding Methodology

**Geocoding Service:** Nominatim (OpenStreetMap) is used for converting country names to geographic coordinates.

**Process:**
1. Extract unique country names from strain metadata
2. Query Nominatim API with rate limiting (1-second delays)
3. Manual verification and correction of problematic entries
4. Coordinate validation and quality control

**Coordinate Validation:** All coordinates are validated by:
- Checking for reasonable latitude/longitude ranges
- Verifying country boundaries using geographic databases
- Manual review of outliers or unexpected locations

#### 4.2 Host Affinity Classification

**Classification System:** Strains are classified into host affinity categories based on isolation source:

- **Human:** Isolated exclusively from human hosts
- **Animal:** Isolated exclusively from animal hosts  
- **Zoonotic:** Isolated from both human and animal hosts
- **Unknown:** Insufficient host information for classification

**Zoonotic Potential Assessment:** Species are classified as having zoonotic potential if:
1. Strains of the same species are isolated from both human and animal hosts
2. Geographic overlap exists between human and animal isolates
3. Phylogenetic analysis supports recent transmission events

### 5. Statistical Analysis Framework

#### 5.1 Phylogenetic Diversity Metrics

**Alpha Diversity:** Within-group phylogenetic diversity calculated using:
- Faith's phylogenetic diversity (PD)
- Mean pairwise distance (MPD)
- Mean nearest taxon distance (MNTD)

**Beta Diversity:** Between-group phylogenetic turnover assessed using:
- UniFrac distances (weighted and unweighted)
- Phylogenetic beta diversity partitioning

#### 5.2 Ancestral State Reconstruction

**Method:** Maximum likelihood ancestral state reconstruction implemented in IQ-TREE using:
- Empirical Bayes method
- Rate heterogeneity modeling
- Statistical confidence assessment (posterior probabilities)

**Character States:** Geographic origin and host affinity are reconstructed as discrete character states across the phylogeny.

**Confidence Thresholds:** Ancestral state assignments with posterior probabilities >0.975 are considered high-confidence predictions.

## Data Quality Control

### 1. Genome Quality Assessment

**Metrics:**
- Assembly statistics (N50, total length, number of contigs)
- Gene prediction completeness
- Contamination screening using CheckM
- Taxonomic classification verification

**Exclusion Criteria:**
- Genomes with <90% completeness
- Genomes with >5% contamination
- Assemblies with excessive fragmentation (>500 contigs for draft genomes)

### 2. Alignment Quality Control

**Assessment Methods:**
- Visual inspection of alignment blocks
- Gap distribution analysis
- Phylogenetic signal assessment
- Removal of poorly aligned regions

**Filtering Criteria:**
- Columns with >50% gaps are removed
- Sequences with <70% coverage are excluded
- Obvious misalignments are manually corrected

### 3. Phylogenetic Signal Evaluation

**Methods:**
- Likelihood mapping analysis
- Quartet puzzling support
- Bootstrap convergence assessment
- Branch length distribution analysis

## Computational Considerations

### Hardware Requirements

**Minimum Specifications:**
- CPU: 8 cores, 2.5 GHz
- RAM: 16 GB
- Storage: 50 GB available space
- Network: Stable internet connection for geocoding

**Recommended Specifications:**
- CPU: 16+ cores, 3.0+ GHz
- RAM: 32+ GB
- Storage: 100+ GB SSD
- Network: High-speed internet connection

### Performance Optimization

**Parallelization:** All computationally intensive steps are parallelized:
- Prokka annotation: Multi-core processing
- IQ-TREE analysis: Automatic thread detection
- Roary pangenome: Parallel gene clustering

**Memory Management:** Large datasets are processed in chunks to prevent memory overflow:
- Alignment processing: Batch processing of gene families
- Tree construction: Memory-efficient algorithms
- Visualization: Progressive rendering for large trees

## Reproducibility Measures

### 1. Version Control

**Software Versions:** All software versions are documented and fixed to ensure reproducibility across different computing environments.

**Random Seeds:** Where applicable, random number generator seeds are set to ensure identical results across runs.

### 2. Logging and Documentation

**Comprehensive Logging:** All analysis steps generate detailed log files containing:
- Command-line parameters
- Software versions
- Runtime statistics
- Error messages and warnings
- Intermediate results

**Parameter Documentation:** All analysis parameters are explicitly documented and justified based on:
- Literature recommendations
- Pilot study results
- Dataset-specific considerations

### 3. Validation Procedures

**Cross-Validation:** Key results are validated using:
- Alternative software implementations
- Different parameter settings
- Subset analyses
- Literature comparison

**Sensitivity Analysis:** The robustness of results is assessed by:
- Varying alignment parameters
- Testing different tree construction methods
- Evaluating the impact of data filtering
- Assessing geographic coordinate accuracy

## Limitations and Considerations

### 1. Methodological Limitations

**Phylogenetic Inference:**
- Midpoint rooting assumes molecular clock behavior
- Limited resolution for very closely related taxa
- Potential impact of horizontal gene transfer

**Geographic Analysis:**
- Geocoding accuracy depends on country name standardization
- Coordinate precision limited to country-level resolution
- Historical country names may introduce uncertainty

**Host Classification:**
- Relies on metadata accuracy and completeness
- May not capture the full spectrum of host range
- Temporal aspects of host adaptation not considered

### 2. Data Limitations

**Sampling Bias:**
- Geographic sampling may not be representative
- Temporal sampling spans different time periods
- Host sampling may be biased toward clinical isolates

**Sequence Quality:**
- Variable genome assembly quality
- Potential contamination in some assemblies
- Missing or incomplete gene annotations

### 3. Computational Limitations

**Scalability:**
- Analysis time increases non-linearly with dataset size
- Memory requirements may limit maximum dataset size
- Geographic API rate limits may slow coordinate acquisition

**Resolution:**
- Phylogenetic resolution limited by sequence divergence
- Geographic resolution limited to country level
- Temporal resolution not explicitly modeled

## Future Improvements

### 1. Methodological Enhancements

**Advanced Phylogenetic Methods:**
- Implementation of species tree methods
- Incorporation of horizontal gene transfer detection
- Time-calibrated phylogenetic analysis

**Enhanced Geographic Analysis:**
- Higher resolution geographic coordinates
- Temporal modeling of geographic spread
- Environmental niche modeling

### 2. Data Integration

**Additional Data Types:**
- Phenotypic data integration
- Antimicrobial resistance profiles
- Virulence factor analysis

**Metadata Enhancement:**
- Standardized host classification systems
- Temporal sampling information
- Environmental context data

### 3. Computational Improvements

**Performance Optimization:**
- GPU acceleration for phylogenetic inference
- Distributed computing for large datasets
- Real-time analysis capabilities

**User Interface:**
- Web-based analysis platform
- Interactive visualization tools
- Automated report generation

