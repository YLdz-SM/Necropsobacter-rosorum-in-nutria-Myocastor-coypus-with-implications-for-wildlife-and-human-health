import re
from scipy.stats import chi2

def extract_log_likelihood(file_path):
    """Extract log-likelihood from IQ-TREE output file"""
    with open(file_path, 'r') as f:
        content = f.read()
    
    # Search for log-likelihood line
    match = re.search(r'Log-likelihood of the tree: (-\d+\.\d+)', content)
    if match:
        return float(match.group(1))
    else:
        raise ValueError(f"Log-likelihood not found in {file_path}")

def count_taxa(file_path):
    """Count number of taxa from IQ-TREE output file"""
    with open(file_path, 'r') as f:
        content = f.read()
    
    # Count sequences in the alignment section
    match = re.search(r'Input data: (\d+) sequences', content)
    if match:
        return int(match.group(1))
    else:
        raise ValueError(f"Number of taxa not found in {file_path}")

def perform_lrt(no_clock_file, with_clock_file):
    """Perform Likelihood Ratio Test for molecular clock"""
    # Extract values from files
    lnL_no_clock = extract_log_likelihood(no_clock_file)
    lnL_with_clock = extract_log_likelihood(with_clock_file)
    n_taxa = count_taxa(no_clock_file)
    
    # Calculate test statistic
    delta = 2 * (lnL_no_clock - lnL_with_clock)
    df = n_taxa - 2  # degrees of freedom
    
    # Calculate p-value
    p_value = 1 - chi2.cdf(delta, df)
    
    # Determine if clock is rejected
    clock_rejected = p_value < 0.05
    
    # Return results
    return {
        'lnL_no_clock': lnL_no_clock,
        'lnL_with_clock': lnL_with_clock,
        'delta': delta,
        'df': df,
        'p_value': p_value,
        'clock_rejected': clock_rejected,
        'n_taxa': n_taxa
    }

def print_results(results):
    """Print formatted results of LRT"""
    print("\nMolecular Clock Likelihood Ratio Test Results")
    print("="*50)
    print(f"{'Number of taxa:':<25} {results['n_taxa']}")
    print(f"{'Log-likelihood (no clock):':<25} {results['lnL_no_clock']:.4f}")
    print(f"{'Log-likelihood (with clock):':<25} {results['lnL_with_clock']:.4f}")
    print(f"{'Test statistic (Δ):':<25} {results['delta']:.4f}")
    print(f"{'Degrees of freedom:':<25} {results['df']}")
    print(f"{'p-value:':<25} {results['p_value']:.6f}")
    print("\nConclusion:")
    if results['clock_rejected']:
        print("The molecular clock hypothesis is REJECTED (p < 0.05).")
        print("-> Midpoint rooting may NOT be appropriate.")
        print("-> Consider using outgroup rooting or other methods.")
    else:
        print("The molecular clock hypothesis is NOT rejected (p ≥ 0.05).")
        print("-> Midpoint rooting may be appropriate.")
    print("="*50)

# Example usage
if __name__ == "__main__":
    no_clock_file = "/Users/younes/Desktop/Last_Revision/Pasteurellaceae-Phylogenomic-Analysis/IQTREESCREP/no_clock.iqtree"
    with_clock_file = "/Users/younes/Desktop/Last_Revision/Pasteurellaceae-Phylogenomic-Analysis/IQTREESCREP/with_clock.iqtree"
    
    try:
        results = perform_lrt(no_clock_file, with_clock_file)
        print_results(results)
    except Exception as e:
        print(f"Error: {e}")
