#!/bin/bash

# MAFFT Multiple Sequence Alignment Script
# This script performs multiple sequence alignment using MAFFT for all FASTA files
# Author: [Your Name]
# Date: [Date]
# Usage: bash mafft_alignment.sh

# Set paths
INPUT_DIR="../data/raw_sequences"
OUTPUT_DIR="../data/alignments"
LOG_DIR="../logs/analysis_logs"

# Create output and log directories if they don't exist
mkdir -p "$OUTPUT_DIR"
mkdir -p "$LOG_DIR"

# Log file
LOG_FILE="$LOG_DIR/mafft_alignment_$(date +%Y%m%d_%H%M%S).log"

echo "Starting MAFFT alignment at $(date)" | tee -a "$LOG_FILE"
echo "Input directory: $INPUT_DIR" | tee -a "$LOG_FILE"
echo "Output directory: $OUTPUT_DIR" | tee -a "$LOG_FILE"

# Function to align sequences
align_sequences() {
    local input_file="$1"
    local output_file="$2"
    local sequence_type="$3"
    
    echo "Aligning: $(basename "$input_file")" | tee -a "$LOG_FILE"
    
    if [ "$sequence_type" == "protein" ]; then
        # For protein sequences
        mafft --auto \
              --adjustdirection \
              --amino \
              --quiet \
              "$input_file" > "$output_file" 2>> "$LOG_FILE"
    else
        # For nucleotide sequences
        mafft --auto \
              --adjustdirection \
              --quiet \
              "$input_file" > "$output_file" 2>> "$LOG_FILE"
    fi
    
    if [ $? -eq 0 ]; then
        echo "Successfully aligned: $(basename "$input_file")" | tee -a "$LOG_FILE"
    else
        echo "Error aligning: $(basename "$input_file")" | tee -a "$LOG_FILE"
    fi
}

# Align protein sequences from Prokka output
echo "Processing protein sequences..." | tee -a "$LOG_FILE"
for fasta_file in "$INPUT_DIR"/../annotations/prokka_outputs/*/*.faa; do
    if [ -f "$fasta_file" ]; then
        base=$(basename "$fasta_file" .faa)
        output_file="$OUTPUT_DIR/individual_gene_alignments/${base}_aligned.fasta"
        align_sequences "$fasta_file" "$output_file" "protein"
    fi
done

# Align 16S rRNA sequences
echo "Processing 16S rRNA sequences..." | tee -a "$LOG_FILE"
for fasta_file in "$INPUT_DIR"/16S_sequences/*.fasta; do
    if [ -f "$fasta_file" ]; then
        base=$(basename "$fasta_file" .fasta)
        output_file="$OUTPUT_DIR/${base}_aligned.fasta"
        align_sequences "$fasta_file" "$output_file" "nucleotide"
    fi
done

# Align core genome sequences (if available)
echo "Processing core genome sequences..." | tee -a "$LOG_FILE"
if [ -f "$INPUT_DIR/core_genome.fasta" ]; then
    align_sequences "$INPUT_DIR/core_genome.fasta" "$OUTPUT_DIR/core_genome_alignment.fasta" "nucleotide"
fi

echo "MAFFT alignment completed at $(date)" | tee -a "$LOG_FILE"
echo "Log file saved to: $LOG_FILE"

