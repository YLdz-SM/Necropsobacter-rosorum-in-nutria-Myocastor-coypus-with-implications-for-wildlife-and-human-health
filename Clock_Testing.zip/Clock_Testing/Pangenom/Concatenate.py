import os
from Bio import SeqIO
from collections import defaultdict

def concatenate_fasta_files(input_dir, output_file):
    """
    Concatenate sequences from all FASTA files in a directory based on sequence IDs.
    
    Args:
        input_dir: Directory containing input FASTA files
        output_file: Path for the output concatenated FASTA file
    """
    # Dictionary to store sequences by ID
    sequences = defaultdict(list)
    
    # Get all FASTA files in the directory
    fasta_files = [f for f in os.listdir(input_dir) if f.endswith(('.fasta', '.fa', '.fna', '.fas'))]
    
    if not fasta_files:
        print(f"No FASTA files found in {input_dir}")
        return
    
    print(f"Found {len(fasta_files)} FASTA files to process...")
    
    # Process each FASTA file
    for fasta_file in fasta_files:
        file_path = os.path.join(input_dir, fasta_file)
        try:
            for record in SeqIO.parse(file_path, "fasta"):
                sequences[record.id].append(str(record.seq))
        except Exception as e:
            print(f"Error processing {fasta_file}: {str(e)}")
            continue
    
    # Write concatenated sequences to output file
    with open(output_file, 'w') as out_handle:
        for seq_id, seq_parts in sequences.items():
            concatenated_seq = ''.join(seq_parts)
            out_handle.write(f">{seq_id}\n{concatenated_seq}\n")
    
    print(f"Successfully wrote {len(sequences)} concatenated sequences to {output_file}")

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description='Concatenate sequences from multiple FASTA files')
    parser.add_argument('-i', '--input_dir', required=True, help='Input directory containing FASTA files')
    parser.add_argument('-o', '--output_file', required=True, help='Output concatenated FASTA file')
    
    args = parser.parse_args()
    
    concatenate_fasta_files(args.input_dir, args.output_file)
