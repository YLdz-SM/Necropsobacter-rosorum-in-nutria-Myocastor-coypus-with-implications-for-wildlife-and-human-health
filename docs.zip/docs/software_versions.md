# Software Versions and Dependencies

This document lists the software versions used in the Pasteurellaceae phylogenomic analysis.

## Core Bioinformatics Tools

| Software | Version | Purpose | Installation |
|----------|---------|---------|--------------|
| Prokka | 1.14.6+ | Genome annotation | `conda install -c bioconda prokka` |
| MAFFT | 7.490+ | Multiple sequence alignment | `conda install -c bioconda mafft` |
| IQ-TREE | 2.1.0+ | Maximum likelihood phylogeny | `conda install -c bioconda iqtree` |
| Roary | 3.13.0+ | Pangenome analysis | `conda install -c bioconda roary` |

## Python Environment

| Package | Version | Purpose |
|---------|---------|---------|
| Python | 3.8+ | Core language |
| pandas | 1.3.0+ | Data manipulation |
| numpy | 1.21.0+ | Numerical computing |
| matplotlib | 3.4.0+ | Plotting |
| plotly | 5.0.0+ | Interactive visualization |
| biopython | 1.79+ | Bioinformatics utilities |
| geopy | 2.2.0+ | Geographic analysis |

## System Requirements

- **Operating System**: Linux/macOS (recommended), Windows (with WSL)
- **Memory**: Minimum 8GB RAM, 16GB+ recommended for large datasets
- **Storage**: At least 10GB free space for analysis outputs
- **CPU**: Multi-core processor recommended (8+ cores optimal)

## Installation Notes

### Conda Environment Setup
```bash
# Create conda environment
conda create -n pasteurella-analysis python=3.8
conda activate pasteurella-analysis

# Install bioinformatics tools
conda install -c bioconda prokka mafft iqtree roary

# Install Python packages
pip install -r requirements.txt
```

### Alternative Installation Methods

#### Ubuntu/Debian
```bash
sudo apt-get update
sudo apt-get install prokka mafft iqtree roary
```

#### macOS (with Homebrew)
```bash
brew install prokka mafft iqtree roary
```

## Version Verification

To verify installed versions:

```bash
# Check tool versions
prokka --version
mafft --version
iqtree --version
roary --version

# Check Python package versions
python -c "import pandas; print(f'pandas: {pandas.__version__}')"
python -c "import numpy; print(f'numpy: {numpy.__version__}')"
python -c "import matplotlib; print(f'matplotlib: {matplotlib.__version__}')"
```

## Compatibility Notes

- **Prokka**: Requires BioPerl and various databases
- **IQ-TREE**: Supports both single-threaded and multi-threaded execution
- **Roary**: Requires MCL clustering software (usually installed automatically)
- **MAFFT**: Multiple algorithms available (auto-selection recommended)

## Updates and Maintenance

This analysis was conducted with the versions listed above. For reproducibility, it's recommended to use the same or compatible versions. If using newer versions, please test compatibility and update this document accordingly.

