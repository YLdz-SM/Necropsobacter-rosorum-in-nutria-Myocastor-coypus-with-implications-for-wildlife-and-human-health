#!/bin/bash

# IQ-TREE Phylogenetic Analysis Script
# This script performs maximum likelihood phylogenetic analysis using IQ-TREE
# Author: [Your Name]
# Date: [Date]
# Usage: bash iqtree_analysis.sh

# Set paths
ALIGNMENT_DIR="../data/alignments"
OUTPUT_DIR="../results/phylogenetic_trees"
LOG_DIR="../logs/iqtree_logs"

# Create output and log directories if they don't exist
mkdir -p "$OUTPUT_DIR"
mkdir -p "$LOG_DIR"

# Main log file
MAIN_LOG="$LOG_DIR/iqtree_analysis_$(date +%Y%m%d_%H%M%S).log"

echo "Starting IQ-TREE phylogenetic analysis at $(date)" | tee -a "$MAIN_LOG"
echo "Alignment directory: $ALIGNMENT_DIR" | tee -a "$MAIN_LOG"
echo "Output directory: $OUTPUT_DIR" | tee -a "$MAIN_LOG"

# Function to run IQ-TREE analysis
run_iqtree() {
    local alignment_file="$1"
    local output_prefix="$2"
    local analysis_type="$3"
    
    echo "Running IQ-TREE for: $(basename "$alignment_file")" | tee -a "$MAIN_LOG"
    
    # Create specific log file for this analysis
    local specific_log="$LOG_DIR/${output_prefix}_iqtree.log"
    
    # Run IQ-TREE with comprehensive options
    iqtree -s "$alignment_file" \
           -pre "$OUTPUT_DIR/$output_prefix" \
           -m MFP \
           -bb 1000 \
           -alrt 1000 \
           -nt AUTO \
           -redo \
           > "$specific_log" 2>&1
    
    # Check if analysis completed successfully
    if [ $? -eq 0 ]; then
        echo "Successfully completed IQ-TREE analysis for: $output_prefix" | tee -a "$MAIN_LOG"
        
        # Copy important output files to results directory
        if [ -f "$OUTPUT_DIR/$output_prefix.treefile" ]; then
            cp "$OUTPUT_DIR/$output_prefix.treefile" "$OUTPUT_DIR/${output_prefix}_ML_tree.newick"
            echo "Tree file saved as: ${output_prefix}_ML_tree.newick" | tee -a "$MAIN_LOG"
        fi
        
        # Save model information
        if [ -f "$OUTPUT_DIR/$output_prefix.iqtree" ]; then
            grep -A 20 "Best-fit model" "$OUTPUT_DIR/$output_prefix.iqtree" > "$OUTPUT_DIR/tree_statistics/${output_prefix}_model_info.txt"
            echo "Model information saved to: tree_statistics/${output_prefix}_model_info.txt" | tee -a "$MAIN_LOG"
        fi
        
    else
        echo "Error in IQ-TREE analysis for: $output_prefix" | tee -a "$MAIN_LOG"
        echo "Check log file: $specific_log" | tee -a "$MAIN_LOG"
    fi
    
    echo "---" | tee -a "$MAIN_LOG"
}

# Create tree statistics directory
mkdir -p "$OUTPUT_DIR/tree_statistics"

# Analyze 16S rRNA alignment
if [ -f "$ALIGNMENT_DIR/16S_alignment.fasta" ]; then
    echo "Processing 16S rRNA alignment..." | tee -a "$MAIN_LOG"
    run_iqtree "$ALIGNMENT_DIR/16S_alignment.fasta" "16S_rRNA" "16S"
fi

# Analyze core genome alignment
if [ -f "$ALIGNMENT_DIR/core_genome_alignment.fasta" ]; then
    echo "Processing core genome alignment..." | tee -a "$MAIN_LOG"
    run_iqtree "$ALIGNMENT_DIR/core_genome_alignment.fasta" "core_genome" "core_genome"
fi

# Analyze individual gene alignments (if needed)
echo "Processing individual gene alignments..." | tee -a "$MAIN_LOG"
for alignment in "$ALIGNMENT_DIR/individual_gene_alignments"/*_aligned.fasta; do
    if [ -f "$alignment" ]; then
        base=$(basename "$alignment" _aligned.fasta)
        run_iqtree "$alignment" "gene_${base}" "gene"
    fi
done

echo "IQ-TREE phylogenetic analysis completed at $(date)" | tee -a "$MAIN_LOG"
echo "Main log file saved to: $MAIN_LOG"
echo "Individual analysis logs saved to: $LOG_DIR"

