#!/bin/bash

# Prokka Genome Annotation Script
# This script performs genome annotation using Prokka for all genome files
# Author: [Your Name]
# Date: [Date]
# Usage: bash prokka_annotation.sh

# Set paths
GENOME_DIR="../data/raw_sequences/genomes"
OUTPUT_DIR="../data/annotations/prokka_outputs"
LOG_DIR="../logs/analysis_logs"

# Create output and log directories if they don't exist
mkdir -p "$OUTPUT_DIR"
mkdir -p "$LOG_DIR"

# Log file
LOG_FILE="$LOG_DIR/prokka_annotation_$(date +%Y%m%d_%H%M%S).log"

echo "Starting Prokka annotation at $(date)" | tee -a "$LOG_FILE"
echo "Input directory: $GENOME_DIR" | tee -a "$LOG_FILE"
echo "Output directory: $OUTPUT_DIR" | tee -a "$LOG_FILE"

# Check if input directory exists
if [ ! -d "$GENOME_DIR" ]; then
    echo "Error: Input directory $GENOME_DIR does not exist" | tee -a "$LOG_FILE"
    exit 1
fi

# Loop through each genome file in the directory
for file in "$GENOME_DIR"/*; do
    if [ -f "$file" ]; then
        base=$(basename "$file")
        # Remove file extension for output directory name
        base_name="${base%.*}"
        outdir="$OUTPUT_DIR/$base_name"
        
        echo "Processing: $base" | tee -a "$LOG_FILE"
        echo "Output directory: $outdir" | tee -a "$LOG_FILE"
        
        # Create output directory
        mkdir -p "$outdir"
        
        # Run Prokka annotation
        prokka --outdir "$outdir" \
               --prefix "$base_name" \
               --cpus 12 \
               --kingdom Bacteria \
               --genus Pasteurella \
               --species "spp" \
               --gram neg \
               --force \
               "$file" 2>&1 | tee -a "$LOG_FILE"
        
        if [ $? -eq 0 ]; then
            echo "Successfully annotated: $base" | tee -a "$LOG_FILE"
        else
            echo "Error annotating: $base" | tee -a "$LOG_FILE"
        fi
        
        echo "---" | tee -a "$LOG_FILE"
    fi
done

echo "Prokka annotation completed at $(date)" | tee -a "$LOG_FILE"
echo "Log file saved to: $LOG_FILE"

