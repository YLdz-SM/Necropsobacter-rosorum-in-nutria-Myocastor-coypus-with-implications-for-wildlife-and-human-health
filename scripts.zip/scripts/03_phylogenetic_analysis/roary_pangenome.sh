#!/bin/bash

# Roary Pangenome Analysis Script
# This script performs pangenome analysis using Roary
# Author: [Your Name]
# Date: [Date]
# Usage: bash roary_pangenome.sh

# Set paths
ANNOTATION_DIR="../data/annotations/prokka_outputs"
OUTPUT_DIR="../results/pangenome_analysis"
LOG_DIR="../logs/roary_logs"

# Create output and log directories if they don't exist
mkdir -p "$OUTPUT_DIR"
mkdir -p "$LOG_DIR"

# Log file
LOG_FILE="$LOG_DIR/roary_analysis_$(date +%Y%m%d_%H%M%S).log"

echo "Starting Roary pangenome analysis at $(date)" | tee -a "$LOG_FILE"
echo "Annotation directory: $ANNOTATION_DIR" | tee -a "$LOG_FILE"
echo "Output directory: $OUTPUT_DIR" | tee -a "$LOG_FILE"

# Check if annotation directory exists and contains GFF files
if [ ! -d "$ANNOTATION_DIR" ]; then
    echo "Error: Annotation directory $ANNOTATION_DIR does not exist" | tee -a "$LOG_FILE"
    exit 1
fi

# Count GFF files
GFF_COUNT=$(find "$ANNOTATION_DIR" -name "*.gff" | wc -l)
echo "Found $GFF_COUNT GFF files for analysis" | tee -a "$LOG_FILE"

if [ "$GFF_COUNT" -eq 0 ]; then
    echo "Error: No GFF files found in $ANNOTATION_DIR" | tee -a "$LOG_FILE"
    echo "Please ensure Prokka annotation has been completed" | tee -a "$LOG_FILE"
    exit 1
fi

# Create Roary output directory
ROARY_OUTPUT="$OUTPUT_DIR/roary_outputs"
mkdir -p "$ROARY_OUTPUT"

# Run Roary pangenome analysis
echo "Running Roary pangenome analysis..." | tee -a "$LOG_FILE"

roary -f "$ROARY_OUTPUT" \
      -e \
      -n \
      -v \
      -p 8 \
      -i 95 \
      -cd 99 \
      "$ANNOTATION_DIR"/*/*.gff 2>&1 | tee -a "$LOG_FILE"

# Check if Roary completed successfully
if [ $? -eq 0 ]; then
    echo "Roary analysis completed successfully" | tee -a "$LOG_FILE"
    
    # Copy important output files to main results directory
    if [ -f "$ROARY_OUTPUT/gene_presence_absence.csv" ]; then
        cp "$ROARY_OUTPUT/gene_presence_absence.csv" "$OUTPUT_DIR/"
        echo "Gene presence/absence matrix copied to main results directory" | tee -a "$LOG_FILE"
    fi
    
    if [ -f "$ROARY_OUTPUT/core_gene_alignment.aln" ]; then
        cp "$ROARY_OUTPUT/core_gene_alignment.aln" "../data/alignments/core_genome_alignment.fasta"
        echo "Core genome alignment copied to alignments directory" | tee -a "$LOG_FILE"
    fi
    
    if [ -f "$ROARY_OUTPUT/summary_statistics.txt" ]; then
        cp "$ROARY_OUTPUT/summary_statistics.txt" "$OUTPUT_DIR/"
        echo "Summary statistics copied to main results directory" | tee -a "$LOG_FILE"
    fi
    
    # Generate summary report
    echo "Generating pangenome summary..." | tee -a "$LOG_FILE"
    echo "=== PANGENOME ANALYSIS SUMMARY ===" > "$OUTPUT_DIR/pangenome_summary.txt"
    echo "Analysis date: $(date)" >> "$OUTPUT_DIR/pangenome_summary.txt"
    echo "Number of genomes analyzed: $GFF_COUNT" >> "$OUTPUT_DIR/pangenome_summary.txt"
    
    if [ -f "$ROARY_OUTPUT/summary_statistics.txt" ]; then
        echo "" >> "$OUTPUT_DIR/pangenome_summary.txt"
        cat "$ROARY_OUTPUT/summary_statistics.txt" >> "$OUTPUT_DIR/pangenome_summary.txt"
    fi
    
else
    echo "Error: Roary analysis failed" | tee -a "$LOG_FILE"
    echo "Check the log file for details: $LOG_FILE" | tee -a "$LOG_FILE"
    exit 1
fi

echo "Roary pangenome analysis completed at $(date)" | tee -a "$LOG_FILE"
echo "Results saved to: $OUTPUT_DIR"
echo "Log file saved to: $LOG_FILE"

